---
title: Water Storage
date: 2025-03-20
layout: wiki 
---

# Water storage

You should store water.
